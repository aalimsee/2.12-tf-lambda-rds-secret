import sys
import logging
import pymysql
import json
import os
import boto3
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS Secrets Manager settings
SECRET_NAME = "rds_credentials"
REGION_NAME = "us-east-1"

def get_secret():
    """
    Retrieve database credentials from AWS Secrets Manager.
    """
    try:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name=REGION_NAME)
        response = client.get_secret_value(SecretId=SECRET_NAME)
        secret = json.loads(response["SecretString"])  # Parse JSON secret
        return secret
    except ClientError as e:
        logger.error(f"Error retrieving secret: {e}")
        raise e

# Fetch RDS credentials from Secrets Manager
db_credentials = get_secret()
username = db_credentials["username"]
password = db_credentials["password"]
rds_endpoint = db_credentials["host"]
db_name = db_credentials["db_name"]
port = int(db_credentials.get("port", 3306))  # Default to 3306 if not provided

# Establish database connection
try:
    conn = pymysql.connect(
        host=rds_endpoint,
        user=username,
        passwd=password,
        db=db_name,
        port=port,
        connect_timeout=5
    )
    logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
except pymysql.MySQLError as e:
    logger.error("ERROR: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

def lambda_handler(event, context):
    """
    AWS Lambda handler function to interact with RDS MySQL.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        # Retrieve secrets again in case of rotation
        db_credentials = get_secret()
        username = db_credentials["username"]
        password = db_credentials["password"]
        
        # Extract data from event
        data = json.loads(event["body"])
        Name = data.get("Name", "Default Movie")  # Fallback if 'Name' not provided

        sql_create_table = """
        CREATE TABLE IF NOT EXISTS Movie (
            MovieID INT NOT NULL AUTO_INCREMENT,
            Name VARCHAR(255) NOT NULL,
            PRIMARY KEY (MovieID)
        )
        """

        sql_insert = "INSERT INTO Movie (Name) VALUES (%s)"

        item_count = 0
        with conn.cursor() as cur:
            cur.execute(sql_create_table)  # Ensure table exists
            cur.execute(sql_insert, (Name,))
            conn.commit()
            
            cur.execute("SELECT * FROM Movie")
            movies = cur.fetchall()
            logger.info("Movies in the database:")
            for row in movies:
                item_count += 1
                logger.info(row)

        return {
            "statusCode": 200,
            "body": json.dumps({"message": f"Added {item_count} items to RDS MySQL table"})
        }

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
